environment    = "prod"
aws_region     = "us-east-1"
project_name   = "devops-demo"
vpc_cidr       = "10.10.0.0/16"

public_subnet_cidrs = ["10.10.1.0/24", "10.10.2.0/24", "10.10.3.0/24"]

instance_type  = "t3.small"
instance_count = 3

tags = {
  Owner      = "platform-team"
  CostCenter = "production"
}
