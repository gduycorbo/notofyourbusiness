environment    = "dev"
aws_region     = "us-east-1"
project_name   = "devops-demo"
vpc_cidr       = "10.0.0.0/16"

public_subnet_cidrs = ["10.0.1.0/24", "10.0.2.0/24"]

instance_type  = "t3.micro"
instance_count = 1

tags = {
  Owner     = "platform-team"
  CostCenter = "dev-sandbox"
}
