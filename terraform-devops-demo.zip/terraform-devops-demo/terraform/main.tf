provider "aws" {
  region = var.aws_region

  default_tags {
    tags = local.common_tags
  }
}

locals {
  common_tags = merge(
    var.tags,
    {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "Terraform"
    }
  )

  name_prefix = "${var.project_name}-${var.environment}"
}

# Módulo de red: VPC, subredes públicas, internet gateway y tabla de rutas
module "vpc" {
  source = "./modules/vpc"

  name_prefix          = local.name_prefix
  vpc_cidr             = var.vpc_cidr
  public_subnet_cidrs  = var.public_subnet_cidrs
  tags                 = local.common_tags
}

# Módulo de cómputo: instancias EC2 dentro de las subredes públicas
module "ec2" {
  source = "./modules/ec2"

  name_prefix     = local.name_prefix
  instance_type   = var.instance_type
  instance_count  = var.instance_count
  subnet_ids      = module.vpc.public_subnet_ids
  vpc_id          = module.vpc.vpc_id
  tags            = local.common_tags
}
