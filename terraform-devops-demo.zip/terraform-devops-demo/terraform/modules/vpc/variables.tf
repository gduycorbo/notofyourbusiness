variable "name_prefix" {
  description = "Prefijo usado para el naming de los recursos de red"
  type        = string
}

variable "vpc_cidr" {
  description = "Bloque CIDR de la VPC"
  type        = string
}

variable "public_subnet_cidrs" {
  description = "Lista de CIDRs para las subredes públicas"
  type        = list(string)
}

variable "tags" {
  description = "Tags comunes a aplicar"
  type        = map(string)
  default     = {}
}
