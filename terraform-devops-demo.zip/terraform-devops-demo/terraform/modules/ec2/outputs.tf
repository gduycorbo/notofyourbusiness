output "instance_ids" {
  description = "IDs de las instancias EC2"
  value       = aws_instance.this[*].id
}

output "public_ips" {
  description = "IPs públicas de las instancias EC2"
  value       = aws_instance.this[*].public_ip
}
