variable "name_prefix" {
  description = "Prefijo usado para el naming de los recursos"
  type        = string
}

variable "instance_type" {
  description = "Tipo de instancia EC2"
  type        = string
}

variable "instance_count" {
  description = "Cantidad de instancias a crear"
  type        = number
  default     = 1
}

variable "subnet_ids" {
  description = "Lista de IDs de subredes donde desplegar las instancias"
  type        = list(string)
}

variable "vpc_id" {
  description = "ID de la VPC donde se crea el security group"
  type        = string
}

variable "tags" {
  description = "Tags comunes a aplicar"
  type        = map(string)
  default     = {}
}
