variable "environment" {
  description = "Nombre del entorno de despliegue (dev, staging, prod)"
  type        = string

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "El valor de \"environment\" debe ser dev, staging o prod."
  }
}

variable "aws_region" {
  description = "Región de AWS donde se despliega la infraestructura"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Nombre del proyecto, usado como prefijo para el naming de recursos"
  type        = string
  default     = "devops-demo"
}

variable "vpc_cidr" {
  description = "Bloque CIDR de la VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "public_subnet_cidrs" {
  description = "Lista de CIDRs para las subredes públicas"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24"]
}

variable "instance_type" {
  description = "Tipo de instancia EC2"
  type        = string
  default     = "t3.micro"
}

variable "instance_count" {
  description = "Cantidad de instancias EC2 a desplegar"
  type        = number
  default     = 1
}

variable "tags" {
  description = "Tags comunes aplicadas a todos los recursos"
  type        = map(string)
  default     = {}
}
