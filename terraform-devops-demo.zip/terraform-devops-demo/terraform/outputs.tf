output "vpc_id" {
  description = "ID de la VPC creada"
  value       = module.vpc.vpc_id
}

output "public_subnet_ids" {
  description = "IDs de las subredes públicas"
  value       = module.vpc.public_subnet_ids
}

output "instance_ids" {
  description = "IDs de las instancias EC2 desplegadas"
  value       = module.ec2.instance_ids
}

output "instance_public_ips" {
  description = "IPs públicas de las instancias EC2"
  value       = module.ec2.public_ips
}
