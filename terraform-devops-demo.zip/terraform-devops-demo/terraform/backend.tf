# Backend remoto: almacena el state file en S3 con bloqueo mediante DynamoDB.
# Los valores de "bucket", "region" y "dynamodb_table" se sobreescriben
# en tiempo de "terraform init" mediante -backend-config, o mediante el
# pipeline de CI/CD, para permitir distintos backends por entorno.

terraform {
  backend "s3" {
    bucket         = "mi-empresa-terraform-state"
    key            = "devops-demo/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "terraform-locks"
    encrypt        = true
  }
}
