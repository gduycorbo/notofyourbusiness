# 🚀 terraform-devops-demo

Repositorio de ejemplo que muestra un flujo de **despliegue de infraestructura como código (IaC)** usando **Terraform**, **Git** y **GitHub Actions**, siguiendo buenas prácticas de DevOps.

## 📌 Objetivo

Este repositorio sirve como plantilla profesional para demostrar:

- Estructura modular de Terraform
- Gestión de múltiples entornos (dev / staging / prod)
- Estado remoto con backend en S3 + bloqueo con DynamoDB
- Pipeline de CI/CD con GitHub Actions (`fmt`, `validate`, `plan`, `apply`)
- Escaneo de seguridad de IaC con `tfsec`
- Convenciones de Git (branching, commits, PRs)

## 🗂️ Estructura del repositorio

```
terraform-devops-demo/
├── .github/
│   └── workflows/
│       └── terraform.yml        # Pipeline CI/CD
├── terraform/
│   ├── main.tf                  # Recursos principales
│   ├── variables.tf             # Definición de variables
│   ├── outputs.tf                # Salidas del módulo raíz
│   ├── versions.tf              # Versiones de Terraform/providers
│   ├── backend.tf               # Configuración de estado remoto
│   └── modules/
│       ├── vpc/                 # Módulo de red
│       └── ec2/                 # Módulo de cómputo
├── environments/
│   ├── dev.tfvars
│   └── prod.tfvars
├── .gitignore
├── .pre-commit-config.yaml
└── README.md
```

## ⚙️ Requisitos previos

- [Terraform](https://developer.hashicorp.com/terraform) >= 1.7
- [AWS CLI](https://aws.amazon.com/cli/) configurado con credenciales válidas
- Cuenta de GitHub con Actions habilitado
- (Opcional) [pre-commit](https://pre-commit.com/) y [tfsec](https://aquasecurity.github.io/tfsec/)

## 🧪 Uso local

```bash
# Clonar el repositorio
git clone https://github.com/tu-usuario/terraform-devops-demo.git
cd terraform-devops-demo/terraform

# Inicializar Terraform (descarga providers y configura backend remoto)
terraform init

# Formatear y validar el código
terraform fmt -recursive
terraform validate

# Planificar cambios para el entorno "dev"
terraform plan -var-file="../environments/dev.tfvars"

# Aplicar cambios (requiere confirmación manual)
terraform apply -var-file="../environments/dev.tfvars"

# Destruir infraestructura (¡usar con cuidado!)
terraform destroy -var-file="../environments/dev.tfvars"
```

## 🔄 Flujo de trabajo con Git (GitFlow simplificado)

| Rama            | Propósito                                  |
|-----------------|---------------------------------------------|
| `main`          | Código estable, listo para producción       |
| `develop`       | Integración de features antes de release    |
| `feature/*`     | Nuevas funcionalidades                       |
| `hotfix/*`      | Correcciones urgentes sobre `main`           |

**Convención de commits** (basada en [Conventional Commits](https://www.conventionalcommits.org/)):

```
feat: agrega módulo de VPC
fix: corrige nombre de tag en instancia EC2
docs: actualiza README con instrucciones de despliegue
chore: actualiza versión de provider AWS
```

## 🔐 Pipeline de CI/CD (GitHub Actions)

El workflow `.github/workflows/terraform.yml` ejecuta automáticamente:

1. **`terraform fmt -check`** – valida formato del código
2. **`terraform validate`** – valida sintaxis y configuración
3. **`tfsec`** – análisis de seguridad estático
4. **`terraform plan`** – en cada Pull Request, publica el plan como comentario
5. **`terraform apply`** – solo al hacer merge a `main`, con aprobación manual (environment protection rules)

## 🌎 Gestión de entornos

Cada entorno tiene su propio archivo `.tfvars` en `environments/`. El backend usa `key` dinámico por entorno para mantener estados separados:

```bash
terraform init -backend-config="key=dev/terraform.tfstate"
terraform init -backend-config="key=prod/terraform.tfstate"
```

## 📄 Licencia

MIT License — libre uso como plantilla base para tus propios proyectos.
